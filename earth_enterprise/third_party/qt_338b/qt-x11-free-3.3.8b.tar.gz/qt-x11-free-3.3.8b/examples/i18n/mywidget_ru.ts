<!DOCTYPE TS><TS>
<context encoding="UTF-8">
    <name>MyWidget</name>
    <message encoding="UTF-8">
        <source>View</source>
        <translation type="unfinished">Вид</translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;File</source>
        <translation type="unfinished">Файл</translation>
    </message>
    <message encoding="UTF-8">
        <source>E&amp;xit</source>
        <translation type="unfinished">Выход</translation>
    </message>
    <message encoding="UTF-8">
        <source>First</source>
        <translation type="unfinished">Первый</translation>
    </message>
    <message encoding="UTF-8">
        <source>Third</source>
        <translation type="unfinished">Третий</translation>
    </message>
    <message encoding="UTF-8">
        <source>Language: English</source>
        <translation type="unfinished">Язык: Русский</translation>
    </message>
    <message encoding="UTF-8">
        <source>The Main Window</source>
        <translation type="unfinished">Главное окно</translation>
    </message>
    <message encoding="UTF-8">
        <source>Oblique</source>
        <translation type="unfinished">Курсив</translation>
    </message>
    <message encoding="UTF-8">
        <source>Second</source>
        <translation type="unfinished">Второй</translation>
    </message>
    <message encoding="UTF-8">
        <source>Isometric</source>
        <translation type="unfinished">Изометрический</translation>
    </message>
    <message encoding="UTF-8">
        <source>Perspective</source>
        <translation type="unfinished">Перспектива</translation>
    </message>
    <message encoding="UTF-8">
        <source>Internationalization Example</source>
        <translation type="unfinished">Пример интернациноализации</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QVDialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
