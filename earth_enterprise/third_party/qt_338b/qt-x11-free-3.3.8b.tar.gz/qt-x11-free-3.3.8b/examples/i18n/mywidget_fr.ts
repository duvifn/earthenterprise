<!DOCTYPE TS><TS>
<context encoding="UTF-8">
    <name>MyWidget</name>
    <message encoding="UTF-8">
        <source>View</source>
        <translation type="unfinished">Vue</translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Fichier</translation>
    </message>
    <message encoding="UTF-8">
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;Quitter</translation>
    </message>
    <message encoding="UTF-8">
        <source>First</source>
        <translation type="unfinished">Premier</translation>
    </message>
    <message encoding="UTF-8">
        <source>Third</source>
        <translation type="unfinished">Troisième</translation>
    </message>
    <message encoding="UTF-8">
        <source>Language: English</source>
        <translation type="unfinished">Langage : Français</translation>
    </message>
    <message encoding="UTF-8">
        <source>The Main Window</source>
        <translation type="unfinished">La fenêtre principale</translation>
    </message>
    <message encoding="UTF-8">
        <source>Ctrl+Q</source>
        <translation type="unfinished">Ctrl+Q</translation>
    </message>
    <message encoding="UTF-8">
        <source>Oblique</source>
        <translation type="unfinished">Oblique</translation>
    </message>
    <message encoding="UTF-8">
        <source>Second</source>
        <translation type="unfinished">Second</translation>
    </message>
    <message encoding="UTF-8">
        <source>Isometric</source>
        <translation type="unfinished">Isométrique</translation>
    </message>
    <message encoding="UTF-8">
        <source>Perspective</source>
        <translation type="unfinished">Perspective</translation>
    </message>
    <message encoding="UTF-8">
        <source>Internationalization Example</source>
        <translation type="unfinished">Exemple d&apos;internationalisation</translation>
    </message>
</context>
<context>
    <name>QVDialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
