delete from spatial_ref_sys where srid = 1;
