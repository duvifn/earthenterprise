insert into spatial_ref_sys(srid,srtext) values (1,'fake["srs"],text');
