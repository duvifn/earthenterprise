#!/bin/bash
#
# Copyright 2015 Google Inc. All Rights Reserved.
# Author: jcgregorio@google.com (Joe Gregorio)
#
# Crude script to update google3 from a local copy of the external git
# repository. This will only create a new subdirectory in /third_party/skia/.
#
# Usage:
#    Update the BRANCH variable then run
#
#      third_party/skia/sync.sh
#
#    From within the third_party/skia directory.
set -x -e

BRANCH=m41

pushd /tmp
git clone https://skia.googlesource.com/skia
pushd /tmp/skia
git fetch
git checkout chrome/${BRANCH}
popd
popd
mkdir ${BRANCH}
rsync -avz
  --exclude=.git/ \
  --exclude=.gitignore \
  --exclude=unix_test_app/ \
  --exclude=trybots_to_run/ \
  --exclude=gyp/ \
  --exclude=animations/ \
  --exclude=README.google \
  --exclude=OWNERS \
  --exclude=google/ \
  --exclude=BUILD \
  /tmp/skia/ \
  ./${BRANCH}


