#ifndef __DataTypes_Test_h__
#define __DataTypes_Test_h__

const double PointEpsilon = 0.000001;
const double SquaredEpsilon = PointEpsilon * PointEpsilon;

#endif
