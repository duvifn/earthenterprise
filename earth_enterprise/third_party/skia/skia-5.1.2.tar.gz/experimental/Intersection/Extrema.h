/*
 * Copyright 2012 Google Inc.
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */
int findExtrema(double a, double b, double c, double d, double tValues[2]);
int findExtrema(double a, double b, double c, double tValue[1]);
