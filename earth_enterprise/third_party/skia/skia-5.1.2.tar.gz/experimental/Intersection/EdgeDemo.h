class SkCanvas;

bool DrawEdgeDemo(SkCanvas* canvas, int step, bool useOld);
