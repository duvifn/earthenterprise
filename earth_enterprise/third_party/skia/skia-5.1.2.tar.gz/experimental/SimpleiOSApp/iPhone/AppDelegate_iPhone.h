//
//  AppDelegate_iPhone.h
//  iosshell
//
//  Created by Yang Su on 6/30/11.
//  Copyright 2011 Google Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate_iPhone : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
