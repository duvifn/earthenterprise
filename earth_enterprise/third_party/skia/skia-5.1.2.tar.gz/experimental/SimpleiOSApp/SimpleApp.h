#import <UIKit/UIKit.h>
#import "SkUIView.h"

@interface SimpleApp : SkUIView
- (id)initWithDefaults;
@end
