//
//  main.m
//  CocoaSampleApp
//
//  Created by Yang Su on 6/14/11.
//  Copyright 2011 Google Inc.
//  Use of this source code is governed by a BSD-style license that can be
//  found in the LICENSE file.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
