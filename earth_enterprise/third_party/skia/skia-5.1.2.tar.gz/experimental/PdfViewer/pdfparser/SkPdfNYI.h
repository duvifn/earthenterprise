#ifndef EXPERIMENTAL_PDFVIEWER_PDFPARSER_SKPDFNYI_H_
#define EXPERIMENTAL_PDFVIEWER_PDFPARSER_SKPDFNYI_H_

struct SkPdfFileSpec {};

// TODO(edisonn): date is actually a string!

struct SkPdfDate {};
struct SkPdfTree {};
struct SkPdfFunction {};


#endif  // EXPERIMENTAL_PDFVIEWER_PDFPARSER_SKPDFNYI_H_
