rm pdfparser/autogen/*
rm pdfparser/native/autogen/*
#python spec2def.py PdfReference-okular-1.txt autogen/pdfspec_autogen.py
#python generate_code.py 'pdfparser/'
